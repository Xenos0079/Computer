I wrote this text file to explain my homework.
I used 3 py.files and each file represents one question in the assignment prief file pdf.
The title q1 means question1, q2 for  question2, etc.
The py. file can not be run directly to answer the question. 
You can use the code below to check my homework.
Run the program and enter them into the terminal to get feedback.
NOTICE THAT q1 and q2 can return the dict (or string) but cannot print it.

q1:
flower = Flower('Sun flower' , 3 , 5.5)
flower.getValue()
print(flower.getValue())

q2:
poly = Polynomial('x^7-x^5+26*x^4+10*x^3-6*x^2+10*x+4')
print(poly.derivative())
polynomial = Polynomial("2*x^3+3*x^2+5*x+1")
print(polynomial.derivative())

q3:
ecosystem = Ecosystem(river_length=10, num_fish=3, num_bears=2)
ecosystem.simulate(steps=5)

Thanks for grading.