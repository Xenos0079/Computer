Int = input('Enter an integer')   #let user to put the target integer,
                                #and the type of input can be string,
                                #but the answer will be correct.

n = 1   #set the initial loop count
for i in Int:  # "Int" is a string, but i can represent the digit of Int    
    print(i)   # print one digit a time  
    n = n+1    # start a new loop
print('Done')  # print "Done" when the process is over
    
    
 
