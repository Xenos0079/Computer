I wrote this text file to explain my homework.
I used 6 py.files and each file represents one question in the assignment prief file pdf.
The title q1 means question1, q2 for  question2, etc.
The py. file can be run directly to answer the question. You may need to input some numbers as the guidetext says in input()
If you wan't to run the code, just open the corresponding py.file and run it directly.
In question5 I defined a new function to judge whether a given interval is a prime number.
For question6 I set "1,2,3" to represent sin, tan and cos. So you have to enter 1, 2, 3 to select the trigonometric function.
Thanks for grading.